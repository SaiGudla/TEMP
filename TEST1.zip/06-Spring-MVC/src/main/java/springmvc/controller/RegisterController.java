package springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import springmvc.model.User_i188;
import springmvc.service.UserService;

@Controller
public class RegisterController {

	@Autowired
	private UserService userService;

	@RequestMapping("/")
	public String showForm() {
		return "registration";
	}

	/*--
	
	@RequestMapping(path = "/processForm", method = RequestMethod.POST)
	public String formHandler(@RequestParam("email") String mail, @RequestParam("userName") String userName,
			@RequestParam("password") String password, Model model) {
		// System.out.println(mail);
		// System.out.println(userName);
		// System.out.println(password);
		model.addAttribute("mail", mail);
		model.addAttribute("userName", userName);
		model.addAttribute("password", password);
		return "success";
	}--*/

	@RequestMapping(path = "/processForm", method = RequestMethod.GET)
	public String formHandler(@ModelAttribute("user") User_i188 user, Model model) {
		this.userService.createUser(user);
		return "success";
	}

}
