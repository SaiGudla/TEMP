package springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/first")
public class HomeController {

	@RequestMapping("/home")
	public String home(Model model) {
		System.out.println("this is home url");
		model.addAttribute("name", "ManiKanta");
		List<String> names = new ArrayList<String>();
		names.add("Mani");
		names.add("Keerthi");
		model.addAttribute("names", names);
		return "index";
	}

	@RequestMapping("/help")
	public ModelAndView help() {
		ModelAndView mav = new ModelAndView();
		mav.addObject("helperId", "283");
		mav.setViewName("help");
		return mav;

	}

}
