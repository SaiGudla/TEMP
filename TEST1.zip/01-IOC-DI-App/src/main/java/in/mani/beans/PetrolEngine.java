package in.mani.beans;

public class PetrolEngine implements IEngine {
	PetrolEngine() {
		System.out.println("PetrolEngine got called...");
	}

	public int start() {
		System.out.println("Petrol Engine Started...");
		return 1;
	}
}
