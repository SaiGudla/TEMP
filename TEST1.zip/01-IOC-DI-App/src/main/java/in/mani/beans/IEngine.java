package in.mani.beans;

public interface IEngine {
	public int start();
}
