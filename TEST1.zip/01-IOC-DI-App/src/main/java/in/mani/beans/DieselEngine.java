package in.mani.beans;

public class DieselEngine {
	DieselEngine() {
		System.out.println("DieselEngine got called..");
	}

	public int start() {
		System.out.println("Diesel Engine Started...");
		return 1;
	}

}
