package in.mani.report;

import org.springframework.stereotype.Service;

@Service
public class ReportService {
	public ReportService() {
		System.out.println("Report Service Called");
	}

}
