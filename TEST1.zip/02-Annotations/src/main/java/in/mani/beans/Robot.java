package in.mani.beans;

public class Robot {

	/**
	 * 
	 */
	public Robot() {
		System.out.println("Robot Called...");
	}

}
