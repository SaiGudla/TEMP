package in.mani.beans;

import org.springframework.stereotype.Service;

@Service
public class UserService {
	public UserService() {
		System.out.println("UserService Called...");
	}
}
