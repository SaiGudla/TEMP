package in.mani.beans;

import org.springframework.stereotype.Repository;

@Repository
public class UserDAO {
	public UserDAO() {
		System.out.println("UserDAO called...");
	}
}
