package in.mani.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import in.mani.beans.Robot;

@Configuration
@ComponentScan(basePackages = { "in.mani" })
public class AppConfig {
	public AppConfig() {
		System.out.println("AppConfig Called");
	}

	@Bean
	public Robot buildRobot() {
		Robot r = new Robot();
		return r;
	}
}
