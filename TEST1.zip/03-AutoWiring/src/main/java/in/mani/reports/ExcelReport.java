package in.mani.reports;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
public class ExcelReport implements IReport {

	public void generateReport() {
		System.out.println("Excel Report Generated...");
	}

}
