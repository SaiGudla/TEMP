package in.mani.reports;

public interface IReport {
	public void generateReport();
}
