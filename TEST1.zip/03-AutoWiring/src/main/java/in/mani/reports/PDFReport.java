package in.mani.reports;

import org.springframework.stereotype.Component;

@Component
public class PDFReport implements IReport {

	public void generateReport() {
		System.out.println("PDF report Generated...");
	}

}
