package in.mani.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.mani.reports.IReport;

@Service
public class ReportService {

	@Autowired
	private IReport report;

	public void generate() {
		report.generateReport();
	}
}
