package in.mani.jdbc;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import in.mani.jdbc.dao.StudentDAO;
import in.mani.jdbc.entities.Student;

public class JDBCDemo {
	public static void main(String[] args) {
		// ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");

		ApplicationContext context = new AnnotationConfigApplicationContext(JDBCConfig.class);

		StudentDAO studentDao = context.getBean("StudentDao", StudentDAO.class);

		/*
		 * Student student = new Student(); student.setRollno(283); student.setName("keerthi");
		 * student.setCity("Palakonda");
		 * 
		 * int result = studentDao.insert(student); System.out.println("insertted " + result);
		 *//*
			 * Student s = studentDao.getStudent(283); System.out.println(s.toString());
			 */
		List<Student> s = studentDao.getAllStudents();
		for (Student ele : s) {
			System.out.println(ele);
		}
	}
}
