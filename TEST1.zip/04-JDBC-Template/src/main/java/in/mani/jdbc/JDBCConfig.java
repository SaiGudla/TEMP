package in.mani.jdbc;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import in.mani.jdbc.dao.StudentDAO;
import in.mani.jdbc.dao.StudentDAOImpl;

@Configuration
public class JDBCConfig {

	@Bean(name = { "ds" })
	public DataSource getDataSource() {
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("org.postgresql.Driver");
		ds.setUrl("jdbc:postgresql://192.168.110.48:5432/plf_training");
		ds.setUsername("plf_training_admin");
		ds.setPassword("pff123");
		return ds;
	}

	@Bean(name = { "jdbcTemplate" })
	public JdbcTemplate getTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(getDataSource());
		return jdbcTemplate;
	}

	@Bean(name = { "StudentDao" })
	public StudentDAO getStudentDao() {
		StudentDAOImpl studentDao = new StudentDAOImpl();
		studentDao.setJdbcTemplate(getTemplate());
		return studentDao;

	}
}
