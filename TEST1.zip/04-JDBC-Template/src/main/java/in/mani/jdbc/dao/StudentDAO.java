package in.mani.jdbc.dao;

import java.util.List;

import in.mani.jdbc.entities.Student;

public interface StudentDAO {
	public int insert(Student s);

	public Student getStudent(int rollno);

	public List<Student> getAllStudents();
}
