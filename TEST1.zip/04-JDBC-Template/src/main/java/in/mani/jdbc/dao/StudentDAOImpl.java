package in.mani.jdbc.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import in.mani.jdbc.entities.Student;

public class StudentDAOImpl implements StudentDAO {

	private JdbcTemplate jdbcTemplate;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int insert(Student s) {
		// TODO Auto-generated method stub
		String query = "insert into student_i188 values(?,?,?)";
		int r = this.jdbcTemplate.update(query, s.getRollno(), s.getName(), s.getCity());
		return r;
	}

	public Student getStudent(int rollno) {
		// TODO Auto-generated method stub
		String query = "select * from student_i188 where rollno=?";

		RowMapper<Student> rowMapper = new RowMapperImpl();
		Student student = this.jdbcTemplate.queryForObject(query, rowMapper, rollno);
		return student;
	}

	public List<Student> getAllStudents() {
		String qry = "select * from student_i188";
		List<Student> students = this.jdbcTemplate.query(qry, new RowMapperImpl());
		return students;
	}

}
