package in.spring.orm;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import in.spring.orm.dao.StudentDAO;
import in.spring.orm.entities.Student;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
		StudentDAO std = context.getBean("studentDao", StudentDAO.class);
		int choice, roll_no;
		String name, city;
		Scanner sc = new Scanner(System.in);
		outer: while (true) {
			System.out.println("1.Create 2.DisplayAll 3.Get Student 4.Delete a Student 5.Update 6.Exit");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter details of Student (rollno,name,city) ::");
				roll_no = sc.nextInt();
				name = sc.next();
				city = sc.next();
				std.insert(new Student(roll_no, name, city));
				System.out.println("Inserted Successfully...!");
				continue;
			case 2:
				System.out.println("Data Retrieved ::");
				List<Student> students = std.getAllStudents();
				for (Student st : students) {
					System.out.println(st);
				}
				continue;
			case 3:
				System.out.println("Enter Student Rollno ::");
				roll_no = sc.nextInt();
				System.out.println(std.getStudent(roll_no));
				continue;
			case 4:
				System.out.println("Enter Student Rollno ::");
				roll_no = sc.nextInt();
				std.deleteStudent(roll_no);
				System.out.println("Deleted Successfully");
				continue;
			case 5:
				System.out.println("Enter details of Student (rollno,name,city) ::");
				roll_no = sc.nextInt();
				name = sc.next();
				city = sc.next();
				std.updateStudent(new Student(roll_no, name, city));
				System.out.println("Updated Successfully...!");
				continue;
			default:
				break;

			}
		}
	}
}
