package in.spring.orm.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_i188")
public class Student {

	@Override
	public String toString() {
		return "Student [roll_no=" + roll_no + ", name=" + name + ", city=" + city + "]";
	}

	@Column(name = "roll_no")
	@Id
	private int roll_no;

	@Column(name = "name")
	private String name;

	@Column(name = "city")
	private String city;

	/**
	 * @param roll_no
	 * @param name
	 * @param city
	 */

	public Student(int roll_no, String name, String city) {

		this.roll_no = roll_no;
		this.name = name;
		this.city = city;
	}

	public int getRoll_no() {
		return roll_no;
	}

	public void setRoll_no(int roll_no) {
		this.roll_no = roll_no;
	}

	/**
	 * 
	 */
	public Student() {
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

}
