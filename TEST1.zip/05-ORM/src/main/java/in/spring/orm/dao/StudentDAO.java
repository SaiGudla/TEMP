package in.spring.orm.dao;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

import in.spring.orm.entities.Student;

public class StudentDAO {
	private HibernateTemplate hibernateTemplate;

	// Creating Student
	@Transactional
	public int insert(Student student) {
		Integer i = (Integer) this.hibernateTemplate.save(student);
		return i;
	}

	// Get Student
	public Student getStudent(int roll_no) {
		Student st = this.hibernateTemplate.get(Student.class, roll_no);
		return st;
	}

	// Retrieving all Students
	public List<Student> getAllStudents() {
		List<Student> students = this.hibernateTemplate.loadAll(Student.class);
		return students;
	}

	// DeleteStudent
	@Transactional
	public void deleteStudent(int roll_no) {
		Student st = this.hibernateTemplate.get(Student.class, roll_no);
		this.hibernateTemplate.delete(st);
	}

	// Updating Data
	@Transactional
	public void updateStudent(Student student) {
		this.hibernateTemplate.update(student);
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

}
